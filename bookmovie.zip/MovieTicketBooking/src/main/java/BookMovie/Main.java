package BookMovie;

import BookMovie.dao.*;
import BookMovie.entities.*;
import BookMovie.util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserDAO userDAO = new UserDAO();
        MovieDAO movieDAO = new MovieDAO();
        BookingDAO bookingDAO = new BookingDAO();

        boolean exit = false;
        while (!exit) {
            System.out.println("1. User Management");
            System.out.println("2. Movie Management");
            System.out.println("3. Booking Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    userManagement(scanner, userDAO);
                    break;
                case 2:
                    movieManagement(scanner, movieDAO);
                    break;
                case 3:
                    bookingManagement(scanner, bookingDAO, movieDAO, userDAO);
                    break;
                case 4:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
        HibernateUtil.shutdown();
        scanner.close();
    }

    private static void userManagement(Scanner scanner, UserDAO userDAO) {
        boolean back = false;
        while (!back) {
            System.out.println("\n1. Register a User");
            System.out.println("2. Update User");
            System.out.println("3. List All Users");
            System.out.println("4. Back to Main Menu");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter user name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String phone = scanner.nextLine();
                    userDAO.addUser(new User(name, phone));
                    System.out.println("User registered successfully!");
                    break;
                case 2:
                    System.out.print("Enter user id to update: ");
                    int userId = scanner.nextInt();
                    scanner.nextLine(); // consume the newline character
                    User user = userDAO.getUserById(userId);
                    if (user != null) {
                        System.out.print("Enter new name: ");
                        user.setName(scanner.nextLine());
                        System.out.print("Enter new phone: ");
                        user.setPhone(scanner.nextLine());
                        userDAO.updateUser(user);
                        System.out.println("User updated successfully!");
                    } else {
                        System.out.println("User not found.");
                    }
                    break;
                case 3:
                    List<User> users = userDAO.getAllUsers();
                    for (User u : users) {
                        System.out.println(u);
                    }
                    break;
                case 4:
                    back = true;
                    break;
                case 5:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void movieManagement(Scanner scanner, MovieDAO movieDAO) {
        boolean back = false;
        while (!back) {
            System.out.println("\n1. Add Movie");
            System.out.println("2. List All Movies");
            System.out.println("3. List Available Seats");
            System.out.println("4. Delete Movie");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter movie name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter timings: ");
                    String timings = scanner.nextLine();
                    System.out.print("Enter available seats: ");
                    int availableSeats = scanner.nextInt();
                    System.out.print("Enter ticket price: ");
                    double ticketPrice = scanner.nextDouble();
                    
                    Movie movie = new Movie(name, timings, availableSeats, ticketPrice);
                    
                    movieDAO.addMovie(movie);
                    System.out.println("Movie added successfully!");
                    break;

                case 2:
                    List<Movie> movies = movieDAO.getAllMovies();
                    for (Movie m : movies) {
                        System.out.println(m);
                    }
                    break;
                case 3:
                    System.out.print("Enter movie id to check seats: ");
                    int movieId = scanner.nextInt();
                    Movie newmovie = movieDAO.getMovieById(movieId);
                    if (newmovie != null) {
                        System.out.println("Available seats: " + newmovie.getAvailableSeats());
                    } else {
                        System.out.println("Movie not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter movie id to delete: ");
                    int deleteMovieId = scanner.nextInt();
                    movieDAO.deleteMovie(deleteMovieId);
                    System.out.println("Movie deleted successfully!");
                    break;
                case 5:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void bookingManagement(Scanner scanner, BookingDAO bookingDAO, MovieDAO movieDAO, UserDAO userDAO) {
        boolean back = false;
        while (!back) {
            System.out.println("\n1. Book Tickets");
            System.out.println("2. View All Bookings");
            System.out.println("3. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                	System.out.print("Enter number of tickets: ");
                    int numberOfTickets = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter movie name: ");
                    String movieName = scanner.nextLine();
                    Movie movie = movieDAO.getMovieByName(movieName);

                    if (movie != null) {
                        if (movie.getAvailableSeats() >= numberOfTickets) {
                            System.out.print("Enter user ids for booking (separate by commas): ");
                            String userIds = scanner.nextLine();
                            String[] userIdArray = userIds.split(",");
                            List<User> bookedUsers = new ArrayList<>();
                            int validBookings = 0;

                            for (String userIdStr : userIdArray) {
                                int userId = Integer.parseInt(userIdStr.trim());
                                User user = userDAO.getUserById(userId);

                                if (user != null) {
                                    Booking booking = new Booking(user, movie, 1);
                                    bookingDAO.addBooking(booking);
                                    bookedUsers.add(user);
                                    validBookings++;
                                } else {
                                    System.out.println("Invalid user id: " + userId);
                                }
                            }

                            if (validBookings == numberOfTickets) {
                                movieDAO.updateAvailableSeats(movie.getMovieId(), numberOfTickets, true);

                                printInvoice(bookedUsers, movie, validBookings);
                                System.out.println("Booking successful!");
                            } else {
                                System.out.println("Booking failed. Either some user IDs are invalid or insufficient seats.");
                            }
                        } else {
                            System.out.println("Not enough available seats.");
                        }
                    } else {
                        System.out.println("Movie not found.");
                    }
                    break;                

                case 2:
                    List<Booking> bookings = bookingDAO.viewAllBookings();
                    for (Booking b : bookings) {
                        System.out.println(b);
                    }
                    break;
                case 3:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void printInvoice(List<User> users, Movie movie, int totalTickets) {
        double totalAmount = movie.getTicketPrice() * totalTickets;
        System.out.println("\n--- Invoice ---");
        System.out.print("Users: \n");
        for (User user : users) {
            System.out.println(user.getName());
        }
        System.out.println("Movie: " + movie.getMovieName());
        System.out.println("Number of Tickets: " + totalTickets);
        System.out.println("Ticket Price: " + movie.getTicketPrice());
        System.out.println("Total Amount: " + totalAmount);
        System.out.println("--------------------");
    }


}
